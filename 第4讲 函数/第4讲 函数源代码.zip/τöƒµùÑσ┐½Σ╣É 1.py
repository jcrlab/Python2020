def sing(person):
    print("Happy birthday to you!")
    print("Happy birthday to you!")
    print("Happy birthday, dear %s." % person)
    print("Happy birthday to you!")
    print("")

sing("Lucy")
sing("Amy")
sing("Fred")
