def happy():
    print("Happy birthday to you!")

def sing(person):
    happy()
    happy()
    print("Happy birthday, dear %s." % person)
    happy()
    print("")

sing("Lucy")
sing("Amy")
sing("Fred")


